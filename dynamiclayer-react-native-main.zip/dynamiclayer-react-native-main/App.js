import App from "./src/containers";

export default App;
